


var butterCount: Double = 2
var rollCount:Double = 1
let CenaMasla: Double = 1
let CenaRozka: Double = 0.1

var customerCount: UInt

customerCount = 14

Double (customerCount) * (butterCount * CenaMasla + rollCount * CenaRozka)

var greeting = "vitajte v nasom obchode, "
var name: String
var greetingWithName: String

name = "Marko"
greetingWithName = greeting + name

var weightOfBagContent: Double?
weightOfBagContent = 4

//   Nakup
let carryOfBag = 10.0  //in kg
let smallButterWeight = 100.0
var smallButterCount = 4.0 // in grams
let milkWeight = 1.0 // in kg
var milkCount = 4.0

var hmotnostNakupu = smallButterCount * smallButterWeight * 0.001  +  milkCount * milkWeight 


if hmotnostNakupu < 10 {
   print ("dokaze to.")
}

if hmotnostNakupu > 10 {
    print ("neunesie to ")
}
 

3<1

Nasa trieda je ako krieda
mina sa tu vzduch
vsetko okolo nas sa tu strieda
mame tu strasny puch
oj ten martin to je slepuch
